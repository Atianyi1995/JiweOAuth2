using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

[System.Serializable]
public class DeviceInfoSerialzeClass
{
    public string gameID;
    public string amount;
    public string orderID;
    public string description;
    public string applyTransactionFeeOn;
    public string idempotencyKey;
    public List<Meta> meta;

}
[System.Serializable]
public class Meta
{

    public string key;
   
}
public class JiweReward : MonoBehaviour
{
    public JiweOAuth2 jiwe;
    public string JiweUrl;
    

    public string GameID;
    public string Amount;
    public string OrderID;
    public string Description;
    public string ApplyTransactionFeeOn;
    public string IdempotencyKey;
    public string Key;
    // Start is called before the first frame update
    void Start()
    {
        JiweUrl = jiwe.access_point;
         
    }
    public void RewardPlayer() 
    {
        DeviceInfoSerialzeClass writePlayer = new DeviceInfoSerialzeClass()
        {
            gameID = GameID.ToString(),
            amount = Amount.ToString(),
            orderID = OrderID.ToString(),
            description = Description.ToString(),
            applyTransactionFeeOn = ApplyTransactionFeeOn.ToString(),
            idempotencyKey = IdempotencyKey.ToString(),

            meta = new List<Meta>
             {
                 new Meta()
                 {
                    key = Key,
                 },
             }

        };
        string jsonString = JsonUtility.ToJson(writePlayer);
        StartCoroutine(Post(JiweUrl, jsonString));
        Debug.Log(jsonString);
    }
    //IEnumerator RewardPlayer2()
    //{
    //    using (UnityWebRequest www = new UnityWebRequest("https://id.jiwe.io/auth?client_id=c200d03e-cf89-11ec-80ac-000d3a9bae12&redirect_uri=https://public.jiwe.io&response_type=id_token&scope=rewards%20in-app-purchases%20profile%20openid&nonce=SOMENONCE&state=SOMERANDOMSTATE"))
    //    {
    //        www.uploadHandler = new UploadHandlerRaw(jsonBytes);
    //        www.downloadHandler = new DownloadHandlerBuffer();
    //        www.SetRequestHeader("api_key", "hasuraengine"); //Pending Change
    //        www.SetRequestHeader("api_secret", "5e3ca84dad0758595a8dc793beb509505e79998bac87ffde128c668ac0215a1ed0462407ac794e99b26041cc3eab266cd06ced0d530b6d02d024d6b49353dd8d");  //Pending Change
    //                                                                                                                                                                                 // use generated api key secret to track user data

    //        yield return www.SendWebRequest();

    //        if (www.isNetworkError || www.isHttpError)
    //        {
    //            Debug.Log(www.error);
    //        }
    //        else
    //        {//Open jiwe.io authentication link
    //            Application.OpenURL("https://id.jiwe.io/auth?client_id=c200d03e-cf89-11ec-80ac-000d3a9bae12&redirect_uri=https://public.jiwe.io&response_type=id_token&scope=rewards%20in-app-purchases%20profile%20openid&nonce=SOMENONCE&state=SOMERANDOMSTATE");
    //            Debug.Log(www.downloadHandler.text);
    //            //StartCoroutine(GetRequest(www.downloadHandler.text));
    //        }
    //    }

    //}
    IEnumerator Post(string url, string bodyJsonString)
    {
        var request = new UnityWebRequest(url, "POST");
        byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJsonString);
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("api_key", "hasuraengine");
        request.SetRequestHeader("api_secret", "5e3ca84dad0758595a8dc793beb509505e79998bac87ffde128c668ac0215a1ed0462407ac794e99b26041cc3eab266cd06ced0d530b6d02d024d6b49353dd8d");
        yield return request.SendWebRequest();
        Debug.Log("Status Code: " + request.responseCode);
    }

}
